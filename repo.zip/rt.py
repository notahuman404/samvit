import os

def resolve_api_keys() -> list[str]:
    keys = []
    itr = 0
    base = "GEMINI_API_KEY"
    while True:
        if itr == 0 :
            key = os.getenv(base)
            if key:
                keys.append(key)
            itr+=1
            continue
        
        key = os.getenv(f"{base}_{itr}")
        if key:
            keys.append(key)
            itr+=1
        else: 
            break
    return keys
print(resolve_api_keys())